/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class APPLEClientStorage {

	/**
	 * Accepted by the &lt;pname&gt; parameters of PixelStore: 
	 */
	public static final int GL_UNPACK_CLIENT_STORAGE_APPLE = 0x85B2;

	private APPLEClientStorage() {}
}
