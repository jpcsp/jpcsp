/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTextureBorderClamp {

	public static final int GL_CLAMP_TO_BORDER_ARB = 0x812D;

	private ARBTextureBorderClamp() {}
}
