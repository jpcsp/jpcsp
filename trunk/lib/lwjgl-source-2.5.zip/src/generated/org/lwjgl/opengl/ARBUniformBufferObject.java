/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBUniformBufferObject {

	/**
	 *  Accepted by the &lt;target&gt; parameters of BindBuffer, BufferData,
	 *  BufferSubData, MapBuffer, UnmapBuffer, GetBufferSubData, and
	 *  GetBufferPointerv:
	 */
	public static final int GL_UNIFORM_BUFFER = 0x8A11;

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetIntegeri_v, GetBooleanv,
	 *  GetIntegerv, GetFloatv, and GetDoublev:
	 */
	public static final int GL_UNIFORM_BUFFER_BINDING = 0x8A28;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetIntegeri_v: 
	 */
	public static final int GL_UNIFORM_BUFFER_START = 0x8A29,
		GL_UNIFORM_BUFFER_SIZE = 0x8A2A;

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_VERTEX_UNIFORM_BLOCKS = 0x8A2B,
		GL_MAX_GEOMETRY_UNIFORM_BLOCKS = 0x8A2C,
		GL_MAX_FRAGMENT_UNIFORM_BLOCKS = 0x8A2D,
		GL_MAX_COMBINED_UNIFORM_BLOCKS = 0x8A2E,
		GL_MAX_UNIFORM_BUFFER_BINDINGS = 0x8A2F,
		GL_MAX_UNIFORM_BLOCK_SIZE = 0x8A30,
		GL_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS = 0x8A31,
		GL_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS = 0x8A32,
		GL_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS = 0x8A33,
		GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT = 0x8A34;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramiv: 
	 */
	public static final int GL_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH = 0x8A35,
		GL_ACTIVE_UNIFORM_BLOCKS = 0x8A36;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetActiveUniformsivARB: 
	 */
	public static final int GL_UNIFORM_TYPE = 0x8A37,
		GL_UNIFORM_SIZE = 0x8A38,
		GL_UNIFORM_NAME_LENGTH = 0x8A39,
		GL_UNIFORM_BLOCK_INDEX = 0x8A3A,
		GL_UNIFORM_OFFSET = 0x8A3B,
		GL_UNIFORM_ARRAY_STRIDE = 0x8A3C,
		GL_UNIFORM_MATRIX_STRIDE = 0x8A3D,
		GL_UNIFORM_IS_ROW_MAJOR = 0x8A3E;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetActiveUniformBlockivARB: 
	 */
	public static final int GL_UNIFORM_BLOCK_BINDING = 0x8A3F,
		GL_UNIFORM_BLOCK_DATA_SIZE = 0x8A40,
		GL_UNIFORM_BLOCK_NAME_LENGTH = 0x8A41,
		GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS = 0x8A42,
		GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES = 0x8A43,
		GL_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER = 0x8A44,
		GL_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER = 0x8A45,
		GL_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER = 0x8A46;

	/**
	 * Returned by GetActiveUniformsivARB and GetUniformBlockIndexARB 
	 */
	public static final int GL_INVALID_INDEX = 0xFFFFFFFF;

	private ARBUniformBufferObject() {}

	public static void glGetUniformIndices(int program, ByteBuffer uniformNames, IntBuffer uniformIndices) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetUniformIndices_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(uniformNames);
		BufferChecks.checkNullTerminated(uniformNames, uniformIndices.remaining());
		BufferChecks.checkDirect(uniformIndices);
		nglGetUniformIndices(program, (uniformIndices.remaining()), uniformNames, uniformNames.position(), uniformIndices, uniformIndices.position(), function_pointer);
	}
	private static native void nglGetUniformIndices(int program, int uniformCount, ByteBuffer uniformNames, int uniformNames_position, IntBuffer uniformIndices, int uniformIndices_position, long function_pointer);

	/** Overloads glGetUniformIndices */
	public static void glGetUniformIndices(int program, CharSequence[] uniformNames, IntBuffer uniformIndices) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetUniformIndices_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(uniformIndices, uniformNames.length);
		nglGetUniformIndices(program, uniformNames.length, APIUtils.getBufferNT(uniformNames), 0, uniformIndices, uniformIndices.position(), function_pointer);
	}

	public static void glGetActiveUniforms(int program, IntBuffer uniformIndices, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformsiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(uniformIndices);
		BufferChecks.checkBuffer(params, uniformIndices.remaining());
		nglGetActiveUniformsiv(program, (uniformIndices.remaining()), uniformIndices, uniformIndices.position(), pname, params, params.position(), function_pointer);
	}
	private static native void nglGetActiveUniformsiv(int program, int uniformCount, IntBuffer uniformIndices, int uniformIndices_position, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetActiveUniformsiv */
	public static int glGetActiveUniforms(int program, int uniformIndex, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformsiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetActiveUniformsiv(program, 1, params.put(1, uniformIndex), 1, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetActiveUniformName(int program, int uniformIndex, IntBuffer length, ByteBuffer uniformName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(uniformName);
		nglGetActiveUniformName(program, uniformIndex, (uniformName.remaining()), length, length != null ? length.position() : 0, uniformName, uniformName.position(), function_pointer);
	}
	private static native void nglGetActiveUniformName(int program, int uniformIndex, int bufSize, IntBuffer length, int length_position, ByteBuffer uniformName, int uniformName_position, long function_pointer);

	/** Overloads glGetActiveUniformName */
	public static String glGetActiveUniformName(int program, int uniformIndex, int bufSize) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer uniformName_length = APIUtils.getLengths();
		ByteBuffer uniformName = APIUtils.getBufferByte(bufSize);
		nglGetActiveUniformName(program, uniformIndex, bufSize, uniformName_length, 0, uniformName, uniformName.position(), function_pointer);
		uniformName.limit(uniformName_length.get(0));
		return APIUtils.getString(uniformName);
	}

	public static int glGetUniformBlockIndex(int program, ByteBuffer uniformBlockName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetUniformBlockIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(uniformBlockName);
		BufferChecks.checkNullTerminated(uniformBlockName);
		int __result = nglGetUniformBlockIndex(program, uniformBlockName, uniformBlockName.position(), function_pointer);
		return __result;
	}
	private static native int nglGetUniformBlockIndex(int program, ByteBuffer uniformBlockName, int uniformBlockName_position, long function_pointer);

	/** Overloads glGetUniformBlockIndex */
	public static int glGetUniformBlockIndex(int program, CharSequence uniformBlockName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetUniformBlockIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		int __result = nglGetUniformBlockIndex(program, APIUtils.getBufferNT(uniformBlockName), 0, function_pointer);
		return __result;
	}

	public static void glGetActiveUniformBlock(int program, int uniformBlockIndex, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformBlockiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 16);
		nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetActiveUniformBlockiv(int program, int uniformBlockIndex, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetActiveUniformBlockiv */
	public static int glGetActiveUniformBlock(int program, int uniformBlockIndex, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformBlockiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetActiveUniformBlockName(int program, int uniformBlockIndex, IntBuffer length, ByteBuffer uniformBlockName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformBlockName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(uniformBlockName);
		nglGetActiveUniformBlockName(program, uniformBlockIndex, (uniformBlockName.remaining()), length, length != null ? length.position() : 0, uniformBlockName, uniformBlockName.position(), function_pointer);
	}
	private static native void nglGetActiveUniformBlockName(int program, int uniformBlockIndex, int bufSize, IntBuffer length, int length_position, ByteBuffer uniformBlockName, int uniformBlockName_position, long function_pointer);

	/** Overloads glGetActiveUniformBlockName */
	public static String glGetActiveUniformBlockName(int program, int uniformBlockIndex, int bufSize) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetActiveUniformBlockName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer uniformBlockName_length = APIUtils.getLengths();
		ByteBuffer uniformBlockName = APIUtils.getBufferByte(bufSize);
		nglGetActiveUniformBlockName(program, uniformBlockIndex, bufSize, uniformBlockName_length, 0, uniformBlockName, uniformBlockName.position(), function_pointer);
		uniformBlockName.limit(uniformBlockName_length.get(0));
		return APIUtils.getString(uniformBlockName);
	}

	public static void glBindBufferRange(int target, int index, int buffer, long offset, long size) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glBindBufferRange_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindBufferRange(target, index, buffer, offset, size, function_pointer);
	}
	private static native void nglBindBufferRange(int target, int index, int buffer, long offset, long size, long function_pointer);

	public static void glBindBufferBase(int target, int index, int buffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glBindBufferBase_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindBufferBase(target, index, buffer, function_pointer);
	}
	private static native void nglBindBufferBase(int target, int index, int buffer, long function_pointer);

	public static void glGetInteger(int value, int index, IntBuffer data) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetIntegeri_v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(data, 4);
		nglGetIntegeri_v(value, index, data, data.position(), function_pointer);
	}
	private static native void nglGetIntegeri_v(int value, int index, IntBuffer data, int data_position, long function_pointer);

	/** Overloads glGetIntegeri_v */
	public static int glGetInteger(int value, int index) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glGetIntegeri_v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer data = APIUtils.getBufferInt();
		nglGetIntegeri_v(value, index, data, data.position(), function_pointer);
		return data.get(0);
	}

	public static void glUniformBlockBinding(int program, int uniformBlockIndex, int uniformBlockBinding) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_uniform_buffer_object_glUniformBlockBinding_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniformBlockBinding(program, uniformBlockIndex, uniformBlockBinding, function_pointer);
	}
	private static native void nglUniformBlockBinding(int program, int uniformBlockIndex, int uniformBlockBinding, long function_pointer);
}
