/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBBlendFuncExtended {

	/**
	 *  Accepted by the &lt;src&gt; and &lt;dst&gt; parameters of BlendFunc and
	 *  BlendFunci, and by the &lt;srcRGB&gt;, &lt;dstRGB&gt;, &lt;srcAlpha&gt; and &lt;dstAlpha&gt;
	 *  parameters of BlendFuncSeparate and BlendFuncSeparatei:
	 */
	public static final int GL_SRC1_COLOR = 0x88F9,
		GL_SRC1_ALPHA = 0x8589,
		GL_ONE_MINUS_SRC1_COLOR = 0x88FA,
		GL_ONE_MINUS_SRC1_ALPHA = 0x88FB;

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv
	 *  and GetDoublev:
	 */
	public static final int GL_MAX_DUAL_SOURCE_DRAW_BUFFERS = 0x88FC;

	private ARBBlendFuncExtended() {}

	public static void glBindFragDataLocationIndexed(int program, int colorNumber, int index, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_blend_func_extended_glBindFragDataLocationIndexed_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(name);
		BufferChecks.checkNullTerminated(name);
		nglBindFragDataLocationIndexed(program, colorNumber, index, name, name.position(), function_pointer);
	}
	private static native void nglBindFragDataLocationIndexed(int program, int colorNumber, int index, ByteBuffer name, int name_position, long function_pointer);

	/** Overloads glBindFragDataLocationIndexed */
	public static void glBindFragDataLocationIndexed(int program, int colorNumber, int index, CharSequence name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_blend_func_extended_glBindFragDataLocationIndexed_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindFragDataLocationIndexed(program, colorNumber, index, APIUtils.getBufferNT(name), 0, function_pointer);
	}

	public static int glGetFragDataIndex(int program, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_blend_func_extended_glGetFragDataIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(name);
		BufferChecks.checkNullTerminated(name);
		int __result = nglGetFragDataIndex(program, name, name.position(), function_pointer);
		return __result;
	}
	private static native int nglGetFragDataIndex(int program, ByteBuffer name, int name_position, long function_pointer);

	/** Overloads glGetFragDataIndex */
	public static int glGetFragDataIndex(int program, CharSequence name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_blend_func_extended_glGetFragDataIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		int __result = nglGetFragDataIndex(program, APIUtils.getBufferNT(name), 0, function_pointer);
		return __result;
	}
}
