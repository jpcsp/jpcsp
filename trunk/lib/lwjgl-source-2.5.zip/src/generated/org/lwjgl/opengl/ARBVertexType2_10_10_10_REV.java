/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBVertexType2_10_10_10_REV {

	/**
	 *  Accepted by the &lt;type&gt; parameter of VertexAttribPointer, VertexPointer,
	 *  NormalPointer, ColorPointer, SecondaryColorPointer, TexCoordPointer,
	 *  VertexAttribP{1234}ui, VertexP*, TexCoordP*, MultiTexCoordP*, NormalP3ui,
	 *  ColorP*, SecondaryColorP* and VertexAttribP*
	 */
	public static final int GL_UNSIGNED_INT_2_10_10_10_REV = 0x8368,
		GL_INT_2_10_10_10_REV = 0x8D9F;

	private ARBVertexType2_10_10_10_REV() {}

	public static void glVertexP2ui(int type, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexP2ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexP2ui(type, value, function_pointer);
	}
	private static native void nglVertexP2ui(int type, int value, long function_pointer);

	public static void glVertexP3ui(int type, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexP3ui(type, value, function_pointer);
	}
	private static native void nglVertexP3ui(int type, int value, long function_pointer);

	public static void glVertexP4ui(int type, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexP4ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexP4ui(type, value, function_pointer);
	}
	private static native void nglVertexP4ui(int type, int value, long function_pointer);

	public static void glVertexP2u(int type, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexP2uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 2);
		nglVertexP2uiv(type, value, value.position(), function_pointer);
	}
	private static native void nglVertexP2uiv(int type, IntBuffer value, int value_position, long function_pointer);

	public static void glVertexP3u(int type, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 3);
		nglVertexP3uiv(type, value, value.position(), function_pointer);
	}
	private static native void nglVertexP3uiv(int type, IntBuffer value, int value_position, long function_pointer);

	public static void glVertexP4u(int type, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexP4uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 4);
		nglVertexP4uiv(type, value, value.position(), function_pointer);
	}
	private static native void nglVertexP4uiv(int type, IntBuffer value, int value_position, long function_pointer);

	public static void glTexCoordP1ui(int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP1ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglTexCoordP1ui(type, coords, function_pointer);
	}
	private static native void nglTexCoordP1ui(int type, int coords, long function_pointer);

	public static void glTexCoordP2ui(int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP2ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglTexCoordP2ui(type, coords, function_pointer);
	}
	private static native void nglTexCoordP2ui(int type, int coords, long function_pointer);

	public static void glTexCoordP3ui(int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglTexCoordP3ui(type, coords, function_pointer);
	}
	private static native void nglTexCoordP3ui(int type, int coords, long function_pointer);

	public static void glTexCoordP4ui(int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP4ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglTexCoordP4ui(type, coords, function_pointer);
	}
	private static native void nglTexCoordP4ui(int type, int coords, long function_pointer);

	public static void glTexCoordP1u(int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP1uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 1);
		nglTexCoordP1uiv(type, coords, coords.position(), function_pointer);
	}
	private static native void nglTexCoordP1uiv(int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glTexCoordP2u(int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP2uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 2);
		nglTexCoordP2uiv(type, coords, coords.position(), function_pointer);
	}
	private static native void nglTexCoordP2uiv(int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glTexCoordP3u(int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 3);
		nglTexCoordP3uiv(type, coords, coords.position(), function_pointer);
	}
	private static native void nglTexCoordP3uiv(int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glTexCoordP4u(int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glTexCoordP4uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 4);
		nglTexCoordP4uiv(type, coords, coords.position(), function_pointer);
	}
	private static native void nglTexCoordP4uiv(int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glMultiTexCoordP1ui(int texture, int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP1ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMultiTexCoordP1ui(texture, type, coords, function_pointer);
	}
	private static native void nglMultiTexCoordP1ui(int texture, int type, int coords, long function_pointer);

	public static void glMultiTexCoordP2ui(int texture, int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP2ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMultiTexCoordP2ui(texture, type, coords, function_pointer);
	}
	private static native void nglMultiTexCoordP2ui(int texture, int type, int coords, long function_pointer);

	public static void glMultiTexCoordP3ui(int texture, int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMultiTexCoordP3ui(texture, type, coords, function_pointer);
	}
	private static native void nglMultiTexCoordP3ui(int texture, int type, int coords, long function_pointer);

	public static void glMultiTexCoordP4ui(int texture, int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP4ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMultiTexCoordP4ui(texture, type, coords, function_pointer);
	}
	private static native void nglMultiTexCoordP4ui(int texture, int type, int coords, long function_pointer);

	public static void glMultiTexCoordP1u(int texture, int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP1uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 1);
		nglMultiTexCoordP1uiv(texture, type, coords, coords.position(), function_pointer);
	}
	private static native void nglMultiTexCoordP1uiv(int texture, int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glMultiTexCoordP2u(int texture, int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP2uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 2);
		nglMultiTexCoordP2uiv(texture, type, coords, coords.position(), function_pointer);
	}
	private static native void nglMultiTexCoordP2uiv(int texture, int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glMultiTexCoordP3u(int texture, int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 3);
		nglMultiTexCoordP3uiv(texture, type, coords, coords.position(), function_pointer);
	}
	private static native void nglMultiTexCoordP3uiv(int texture, int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glMultiTexCoordP4u(int texture, int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glMultiTexCoordP4uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 4);
		nglMultiTexCoordP4uiv(texture, type, coords, coords.position(), function_pointer);
	}
	private static native void nglMultiTexCoordP4uiv(int texture, int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glNormalP3ui(int type, int coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glNormalP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglNormalP3ui(type, coords, function_pointer);
	}
	private static native void nglNormalP3ui(int type, int coords, long function_pointer);

	public static void glNormalP3u(int type, IntBuffer coords) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glNormalP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(coords, 3);
		nglNormalP3uiv(type, coords, coords.position(), function_pointer);
	}
	private static native void nglNormalP3uiv(int type, IntBuffer coords, int coords_position, long function_pointer);

	public static void glColorP3ui(int type, int color) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glColorP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglColorP3ui(type, color, function_pointer);
	}
	private static native void nglColorP3ui(int type, int color, long function_pointer);

	public static void glColorP4ui(int type, int color) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glColorP4ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglColorP4ui(type, color, function_pointer);
	}
	private static native void nglColorP4ui(int type, int color, long function_pointer);

	public static void glColorP3u(int type, IntBuffer color) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glColorP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(color, 3);
		nglColorP3uiv(type, color, color.position(), function_pointer);
	}
	private static native void nglColorP3uiv(int type, IntBuffer color, int color_position, long function_pointer);

	public static void glColorP4u(int type, IntBuffer color) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glColorP4uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(color, 4);
		nglColorP4uiv(type, color, color.position(), function_pointer);
	}
	private static native void nglColorP4uiv(int type, IntBuffer color, int color_position, long function_pointer);

	public static void glSecondaryColorP3ui(int type, int color) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glSecondaryColorP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglSecondaryColorP3ui(type, color, function_pointer);
	}
	private static native void nglSecondaryColorP3ui(int type, int color, long function_pointer);

	public static void glSecondaryColorP3u(int type, IntBuffer color) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glSecondaryColorP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(color, 3);
		nglSecondaryColorP3uiv(type, color, color.position(), function_pointer);
	}
	private static native void nglSecondaryColorP3uiv(int type, IntBuffer color, int color_position, long function_pointer);

	public static void glVertexAttribP1ui(int index, int type, boolean normalized, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP1ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribP1ui(index, type, normalized, value, function_pointer);
	}
	private static native void nglVertexAttribP1ui(int index, int type, boolean normalized, int value, long function_pointer);

	public static void glVertexAttribP2ui(int index, int type, boolean normalized, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP2ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribP2ui(index, type, normalized, value, function_pointer);
	}
	private static native void nglVertexAttribP2ui(int index, int type, boolean normalized, int value, long function_pointer);

	public static void glVertexAttribP3ui(int index, int type, boolean normalized, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP3ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribP3ui(index, type, normalized, value, function_pointer);
	}
	private static native void nglVertexAttribP3ui(int index, int type, boolean normalized, int value, long function_pointer);

	public static void glVertexAttribP4ui(int index, int type, boolean normalized, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP4ui_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribP4ui(index, type, normalized, value, function_pointer);
	}
	private static native void nglVertexAttribP4ui(int index, int type, boolean normalized, int value, long function_pointer);

	public static void glVertexAttribP1u(int index, int type, boolean normalized, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP1uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 1);
		nglVertexAttribP1uiv(index, type, normalized, value, value.position(), function_pointer);
	}
	private static native void nglVertexAttribP1uiv(int index, int type, boolean normalized, IntBuffer value, int value_position, long function_pointer);

	public static void glVertexAttribP2u(int index, int type, boolean normalized, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP2uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 2);
		nglVertexAttribP2uiv(index, type, normalized, value, value.position(), function_pointer);
	}
	private static native void nglVertexAttribP2uiv(int index, int type, boolean normalized, IntBuffer value, int value_position, long function_pointer);

	public static void glVertexAttribP3u(int index, int type, boolean normalized, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP3uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 3);
		nglVertexAttribP3uiv(index, type, normalized, value, value.position(), function_pointer);
	}
	private static native void nglVertexAttribP3uiv(int index, int type, boolean normalized, IntBuffer value, int value_position, long function_pointer);

	public static void glVertexAttribP4u(int index, int type, boolean normalized, IntBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_vertex_type_2_10_10_10_rev_glVertexAttribP4uiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(value, 4);
		nglVertexAttribP4uiv(index, type, normalized, value, value.position(), function_pointer);
	}
	private static native void nglVertexAttribP4uiv(int index, int type, boolean normalized, IntBuffer value, int value_position, long function_pointer);
}
