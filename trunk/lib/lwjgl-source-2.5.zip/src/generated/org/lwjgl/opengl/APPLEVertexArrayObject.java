/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class APPLEVertexArrayObject {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 *  and GetDoublev:
	 */
	public static final int GL_VERTEX_ARRAY_BINDING_APPLE = 0x85B5;

	private APPLEVertexArrayObject() {}

	public static void glBindVertexArrayAPPLE(int array) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_vertex_array_object_glBindVertexArrayAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindVertexArrayAPPLE(array, function_pointer);
	}
	private static native void nglBindVertexArrayAPPLE(int array, long function_pointer);

	public static void glDeleteVertexArraysAPPLE(IntBuffer arrays) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_vertex_array_object_glDeleteVertexArraysAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(arrays);
		nglDeleteVertexArraysAPPLE((arrays.remaining()), arrays, arrays.position(), function_pointer);
	}
	private static native void nglDeleteVertexArraysAPPLE(int n, IntBuffer arrays, int arrays_position, long function_pointer);

	/** Overloads glDeleteVertexArraysAPPLE */
	public static void glDeleteVertexArraysAPPLE(int array) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_vertex_array_object_glDeleteVertexArraysAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteVertexArraysAPPLE(1, APIUtils.getBufferInt().put(0, array), 0, function_pointer);
	}

	public static void glGenVertexArraysAPPLE(IntBuffer arrays) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_vertex_array_object_glGenVertexArraysAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(arrays);
		nglGenVertexArraysAPPLE((arrays.remaining()), arrays, arrays.position(), function_pointer);
	}
	private static native void nglGenVertexArraysAPPLE(int n, IntBuffer arrays, int arrays_position, long function_pointer);

	/** Overloads glGenVertexArraysAPPLE */
	public static int glGenVertexArraysAPPLE() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_vertex_array_object_glGenVertexArraysAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer arrays = APIUtils.getBufferInt();
		nglGenVertexArraysAPPLE(1, arrays, arrays.position(), function_pointer);
		return arrays.get(0);
	}

	public static boolean glIsVertexArrayAPPLE(int array) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_vertex_array_object_glIsVertexArrayAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsVertexArrayAPPLE(array, function_pointer);
		return __result;
	}
	private static native boolean nglIsVertexArrayAPPLE(int array, long function_pointer);
}
