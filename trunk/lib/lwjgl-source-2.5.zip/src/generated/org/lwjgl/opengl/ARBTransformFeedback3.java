/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTransformFeedback3 {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetIntegerv,
	 *  and GetFloatv:
	 */
	public static final int GL_MAX_TRANSFORM_FEEDBACK_BUFFERS = 0x8E70,
		GL_MAX_VERTEX_STREAMS = 0x8E71;

	private ARBTransformFeedback3() {}

	public static void glDrawTransformFeedbackStream(int mode, int id, int stream) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback3_glDrawTransformFeedbackStream_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDrawTransformFeedbackStream(mode, id, stream, function_pointer);
	}
	private static native void nglDrawTransformFeedbackStream(int mode, int id, int stream, long function_pointer);

	public static void glBeginQueryIndexed(int target, int index, int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback3_glBeginQueryIndexed_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBeginQueryIndexed(target, index, id, function_pointer);
	}
	private static native void nglBeginQueryIndexed(int target, int index, int id, long function_pointer);

	public static void glEndQueryIndexed(int target, int index) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback3_glEndQueryIndexed_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglEndQueryIndexed(target, index, function_pointer);
	}
	private static native void nglEndQueryIndexed(int target, int index, long function_pointer);

	public static void glGetQueryIndexed(int target, int index, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback3_glGetQueryIndexediv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetQueryIndexediv(target, index, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetQueryIndexediv(int target, int index, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetQueryIndexediv */
	public static int glGetQueryIndexed(int target, int index, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback3_glGetQueryIndexediv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetQueryIndexediv(target, index, pname, params, params.position(), function_pointer);
		return params.get(0);
	}
}
