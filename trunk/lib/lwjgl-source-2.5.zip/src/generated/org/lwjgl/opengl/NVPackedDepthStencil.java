/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVPackedDepthStencil {

	public static final int GL_DEPTH_STENCIL_NV = 0x84F9,
		GL_UNSIGNED_INT_24_8_NV = 0x84FA;

	private NVPackedDepthStencil() {}
}
