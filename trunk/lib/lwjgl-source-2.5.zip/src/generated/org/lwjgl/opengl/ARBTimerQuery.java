/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTimerQuery {

	/**
	 *  Accepted by the &lt;target&gt; parameter of BeginQuery, EndQuery, and
	 *  GetQueryiv:
	 */
	public static final int GL_TIME_ELAPSED = 0x88BF;

	/**
	 *  Accepted by the &lt;target&gt; parameter of GetQueryiv and QueryCounter.
	 *  Accepted by the &lt;value&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetInteger64v, GetFloatv, and GetDoublev:
	 */
	public static final int GL_TIMESTAMP = 0x8E28;

	private ARBTimerQuery() {}

	public static void glQueryCounter(int id, int target) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_timer_query_glQueryCounter_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglQueryCounter(id, target, function_pointer);
	}
	private static native void nglQueryCounter(int id, int target, long function_pointer);

	public static void glGetQueryObject(int id, int pname, LongBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_timer_query_glGetQueryObjecti64v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetQueryObjecti64v(id, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetQueryObjecti64v(int id, int pname, LongBuffer params, int params_position, long function_pointer);

	/** Overloads glGetQueryObjecti64v */
	public static long glGetQueryObject(int id, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_timer_query_glGetQueryObjecti64v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		LongBuffer params = APIUtils.getBufferLong();
		nglGetQueryObjecti64v(id, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetQueryObjectu(int id, int pname, LongBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_timer_query_glGetQueryObjectui64v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetQueryObjectui64v(id, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetQueryObjectui64v(int id, int pname, LongBuffer params, int params_position, long function_pointer);

	/** Overloads glGetQueryObjectui64v */
	public static long glGetQueryObjectu(int id, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_timer_query_glGetQueryObjectui64v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		LongBuffer params = APIUtils.getBufferLong();
		nglGetQueryObjectui64v(id, pname, params, params.position(), function_pointer);
		return params.get(0);
	}
}
