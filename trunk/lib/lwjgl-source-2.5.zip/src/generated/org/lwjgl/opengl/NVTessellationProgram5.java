/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVTessellationProgram5 {

	/**
	 *  Accepted by the &lt;cap&gt; parameter of Disable, Enable, and IsEnabled,
	 *  by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 *  and GetDoublev, and by the &lt;target&gt; parameter of ProgramStringARB,
	 *  BindProgramARB, ProgramEnvParameter4[df][v]ARB,
	 *  ProgramLocalParameter4[df][v]ARB, GetProgramEnvParameter[df]vARB,
	 *  GetProgramLocalParameter[df]vARB, GetProgramivARB and
	 *  GetProgramStringARB:
	 */
	public static final int GL_TESS_CONTROL_PROGRAM_NV = 0x891E,
		GL_TESS_EVALUATION_PROGRAM_NV = 0x891F;

	/**
	 *  Accepted by the &lt;target&gt; parameter of ProgramBufferParametersfvNV,
	 *  ProgramBufferParametersIivNV, and ProgramBufferParametersIuivNV,
	 *  BindBufferRangeNV, BindBufferOffsetNV, BindBufferBaseNV, and BindBuffer
	 *  and the &lt;value&gt; parameter of GetIntegerIndexedvEXT:
	 */
	public static final int GL_TESS_CONTROL_PROGRAM_PARAMETER_BUFFER_NV = 0x8C74,
		GL_TESS_EVALUATION_PROGRAM_PARAMETER_BUFFER_NV = 0x8C75;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramivARB: 
	 */
	public static final int GL_MAX_PROGRAM_PATCH_ATTRIBS_NV = 0x86D8;

	private NVTessellationProgram5() {}
}
