/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBGpuShaderFp64 {

	/**
	 *  Returned in the &lt;type&gt; parameter of GetActiveUniform, and
	 *  GetTransformFeedbackVarying:
	 */
	public static final int GL_DOUBLE = 0x140A,
		GL_DOUBLE_VEC2 = 0x8FFC,
		GL_DOUBLE_VEC3 = 0x8FFD,
		GL_DOUBLE_VEC4 = 0x8FFE,
		GL_DOUBLE_MAT2 = 0x8F46,
		GL_DOUBLE_MAT3 = 0x8F47,
		GL_DOUBLE_MAT4 = 0x8F48,
		GL_DOUBLE_MAT2x3 = 0x8F49,
		GL_DOUBLE_MAT2x4 = 0x8F4A,
		GL_DOUBLE_MAT3x2 = 0x8F4B,
		GL_DOUBLE_MAT3x4 = 0x8F4C,
		GL_DOUBLE_MAT4x2 = 0x8F4D,
		GL_DOUBLE_MAT4x3 = 0x8F4E;

	private ARBGpuShaderFp64() {}

	public static void glUniform1d(int location, double x) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform1d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform1d(location, x, function_pointer);
	}
	private static native void nglUniform1d(int location, double x, long function_pointer);

	public static void glUniform2d(int location, double x, double y) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform2d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform2d(location, x, y, function_pointer);
	}
	private static native void nglUniform2d(int location, double x, double y, long function_pointer);

	public static void glUniform3d(int location, double x, double y, double z) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform3d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform3d(location, x, y, z, function_pointer);
	}
	private static native void nglUniform3d(int location, double x, double y, double z, long function_pointer);

	public static void glUniform4d(int location, double x, double y, double z, double w) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform4d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform4d(location, x, y, z, w, function_pointer);
	}
	private static native void nglUniform4d(int location, double x, double y, double z, double w, long function_pointer);

	public static void glUniform1(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform1dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform1dv(location, (value.remaining()), value, value.position(), function_pointer);
	}
	private static native void nglUniform1dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniform2(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform2dv(location, (value.remaining()) >> 1, value, value.position(), function_pointer);
	}
	private static native void nglUniform2dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniform3(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform3dv(location, (value.remaining()) / 3, value, value.position(), function_pointer);
	}
	private static native void nglUniform3dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniform4(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniform4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform4dv(location, (value.remaining()) >> 2, value, value.position(), function_pointer);
	}
	private static native void nglUniform4dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix2(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix2dv(location, (value.remaining()) >> 2, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix2dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix3(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix3dv(location, (value.remaining()) / (3 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix3dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix4(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix4dv(location, (value.remaining()) >> 4, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix4dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix2x3(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix2x3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix2x3dv(location, (value.remaining()) / (2 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix2x3dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix2x4(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix2x4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix2x4dv(location, (value.remaining()) >> 3, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix2x4dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix3x2(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix3x2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix3x2dv(location, (value.remaining()) / (3 * 2), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix3x2dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix3x4(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix3x4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix3x4dv(location, (value.remaining()) / (3 * 4), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix3x4dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix4x2(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix4x2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix4x2dv(location, (value.remaining()) >> 3, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix4x2dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix4x3(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glUniformMatrix4x3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix4x3dv(location, (value.remaining()) / (4 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix4x3dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glGetUniform(int program, int location, DoubleBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glGetUniformdv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(params);
		nglGetUniformdv(program, location, params, params.position(), function_pointer);
	}
	private static native void nglGetUniformdv(int program, int location, DoubleBuffer params, int params_position, long function_pointer);

	public static void glProgramUniform1dEXT(int program, int location, double x) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform1dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglProgramUniform1dEXT(program, location, x, function_pointer);
	}
	private static native void nglProgramUniform1dEXT(int program, int location, double x, long function_pointer);

	public static void glProgramUniform2dEXT(int program, int location, double x, double y) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform2dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglProgramUniform2dEXT(program, location, x, y, function_pointer);
	}
	private static native void nglProgramUniform2dEXT(int program, int location, double x, double y, long function_pointer);

	public static void glProgramUniform3dEXT(int program, int location, double x, double y, double z) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform3dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglProgramUniform3dEXT(program, location, x, y, z, function_pointer);
	}
	private static native void nglProgramUniform3dEXT(int program, int location, double x, double y, double z, long function_pointer);

	public static void glProgramUniform4dEXT(int program, int location, double x, double y, double z, double w) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform4dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglProgramUniform4dEXT(program, location, x, y, z, w, function_pointer);
	}
	private static native void nglProgramUniform4dEXT(int program, int location, double x, double y, double z, double w, long function_pointer);

	public static void glProgramUniform1EXT(int program, int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform1dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniform1dvEXT(program, location, (value.remaining()), value, value.position(), function_pointer);
	}
	private static native void nglProgramUniform1dvEXT(int program, int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniform2EXT(int program, int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform2dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniform2dvEXT(program, location, (value.remaining()) >> 1, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniform2dvEXT(int program, int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniform3EXT(int program, int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform3dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniform3dvEXT(program, location, (value.remaining()) / 3, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniform3dvEXT(int program, int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniform4EXT(int program, int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniform4dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniform4dvEXT(program, location, (value.remaining()) >> 2, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniform4dvEXT(int program, int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix2EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix2dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix2dvEXT(program, location, (value.remaining()) >> 2, transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix2dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix3EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix3dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix3dvEXT(program, location, (value.remaining()) / (3 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix3dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix4EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix4dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix4dvEXT(program, location, (value.remaining()) >> 4, transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix4dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix2x3EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix2x3dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix2x3dvEXT(program, location, (value.remaining()) / (2 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix2x3dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix2x4EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix2x4dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix2x4dvEXT(program, location, (value.remaining()) >> 3, transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix2x4dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix3x2EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix3x2dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix3x2dvEXT(program, location, (value.remaining()) / (3 * 2), transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix3x2dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix3x4EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix3x4dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix3x4dvEXT(program, location, (value.remaining()) / (3 * 4), transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix3x4dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix4x2EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix4x2dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix4x2dvEXT(program, location, (value.remaining()) >> 3, transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix4x2dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glProgramUniformMatrix4x3EXT(int program, int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_gpu_shader_fp64_glProgramUniformMatrix4x3dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformMatrix4x3dvEXT(program, location, (value.remaining()) / (4 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformMatrix4x3dvEXT(int program, int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);
}
