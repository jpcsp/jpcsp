/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureLODBias {

	public static final int GL_TEXTURE_FILTER_CONTROL_EXT = 0x8500,
		GL_TEXTURE_LOD_BIAS_EXT = 0x8501,
		GL_MAX_TEXTURE_LOD_BIAS_EXT = 0x84FD;

	private EXTTextureLODBias() {}
}
