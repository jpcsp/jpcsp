/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVMultisampleFilterHint {

	/**
	 *  Accepted by the &lt;target&gt; parameter of Hint and by the &lt;pname&gt;
	 *  parameter of GetBooleanv, GetIntegerv, GetFloatv, and GetDoublev:
	 */
	public static final int GL_MULTISAMPLE_FILTER_HINT_NV = 0x8534;

	private NVMultisampleFilterHint() {}
}
